/* 
 * File:   ADC.h
 * Author: Benjamin Todd 
 *
 * Created on April 15, 2020, 10:37 PM
 */

#ifndef ADC_H
#define	ADC_H

unsigned int read_ADC(char channel);
int volume_out(int an_in, int current_vol);

#endif

