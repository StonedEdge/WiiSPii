
 
#ifndef PPS_H
#define	PPS_H

#include <xc.h> // include processor files - each processor file is guarded. 

void PPS_unlock();
void PPS_lock();

#endif	