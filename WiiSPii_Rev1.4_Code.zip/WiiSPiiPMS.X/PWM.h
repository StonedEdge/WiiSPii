
 
#ifndef PWM_H
#define	PWM_H

#include <xc.h> // include processor files - each processor file is guarded. 

void PWM_INIT();
void PWM_power_down();
void PWM_power_up();

#endif	